var phylop = db.GRCh38_refgeneScores_5.find({"_id.c":X})
while(phylop.hasNext())
{	printjsononeline(phylop.next())}