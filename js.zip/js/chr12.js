var phylop = db.GRCh38_refgeneScores_5.find({"_id.c":12})
while(phylop.hasNext())
{	printjsononeline(phylop.next())}