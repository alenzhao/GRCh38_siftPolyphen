var phylop = db.GRCh38_refgeneScores_5.find({"_id.c":4})
while(phylop.hasNext())
{	printjsononeline(phylop.next())}