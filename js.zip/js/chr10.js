var phylop = db.GRCh38_refgeneScores_5.find({"_id.c":10})
while(phylop.hasNext())
{	printjsononeline(phylop.next())}