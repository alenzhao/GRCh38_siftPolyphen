var phylop = db.GRCh38_refgeneScores_5.find({"_id.c":7})
while(phylop.hasNext())
{	printjsononeline(phylop.next())}